# Tavern In-Game Hub

**Version 2.3.1 · Tavern Launcher 1.8.3 / 1.8.4 · Windows PC VR**

Choose servers and use friends, invitations, and the social tablet inside A Township Tale.

## Before you start

- Install Tavern Launcher Client **1.8.3 or 1.8.4**.
- Use its **Patch** and **Mods** controls to prepare your compatible Windows game and install Mono MelonLoader.
- Save your username, game path, and platform in Tavern Launcher.
- Setup requires **.NET Framework 4.8** and **Windows PowerShell 5.1**.

This package does not include the game, launcher, MelonLoader, or TavernLib.

## Install

1. Extract this ZIP and close the game and launcher.
2. Open **TavernHubSetup.exe**.
3. Select **A Township Tale.exe** from your game folder.
4. Select **TavernLauncher - Client.exe** from your launcher folder.
5. Click **Install / Update**. Wait for the live log to confirm completion.
6. Open Tavern Launcher and click **Play Game**. Select a server inside the game.

No commands or compiling required. Use **Check setup** to check compatibility or **Save log** to save an error report.

## Update an existing installation

Run the new setup EXE and choose **Install / Update**, selecting your existing game and your current launcher EXE. A new launcher folder is supported. You do not need to uninstall first. Your settings, friends, saved servers, and original Undo backups are preserved.

If upgrading Tavern Launcher to 1.8.4, apply its updated client patch first. Close it before running this setup. Setup installs its add-on into your selected launcher folder and leaves the old launcher folder unchanged. Undo restores the new folder's pre-update files; the original game backups are retained.

Previously called **Tavern Native Menu**, this release keeps the existing mod filenames and recovery folders so updates and Undo continue to work. Do not rename those installed files or folders.

## Server hosts

1. Stop the game server.
2. Open the same setup EXE and click **Install server support...**.
3. Select the patched game-server folder containing **A Township Tale.exe**.
4. Wait for completion, then start the server.

This enables friendship cards and full tablet support. Both players need the current client mod for friendship actions. Moderation permissions come from the server's Tavern **moderator** and **owner** roles.

## Using it

- **Servers on PC:** open the launcher's **Saved & Recent Servers**, choose **Favourites → + Add Server**, enter the host's address, game/auth ports, and server type, then click **Add**. It appears in VR Favorites and Saved / Recent shortly, including while the menu is already open.
- **Servers in VR:** browse community servers, or choose **Add a private server...** to save your own address. Password and whitelist rules still apply.
- **Friends:** share a friend code, exchange cards on a supported server, or select a player on the social tablet. The recipient must accept.
- **Invitations:** select a friend and invite them to a saved server. Both games must be online for delivery.
- **Tablet:** view players, mute or block them, and use moderation controls if your role allows it.

Networking starts automatically. There is no separate friends relay app to run; discovery and connection assistance use public Tox infrastructure. Only accepted friends appear in the friends list. If upgrading from the old relay version, add those friends once again.

## Remove or troubleshoot

Close the game and launcher, then choose **Undo setup**. Server hosts can use **Undo server support...**. Keep the original backup folders until you no longer need Undo.

- **Missing Play Game button:** restart the selected launcher and enable **Tavern In-Game Hub - Play Game** in Addons.
- **Missing tablet actions:** update the server companion using **Install server support...**.
- **Friends offline:** keep both games open, allow discovery time, and check network status on the friends board.
- **Friend card fails:** both players must install this mod, and the host must update server support. Hand the card directly to the other player. A player without the mod cannot be added to the peer friends list; use friend codes if the server has no companion.
- **Setup error:** save the log and include the exact error in your bug report. Review personal paths before sharing logs; keep identity and credential files private.

## Source and antivirus reports

**TavernHubSource.zip** contains the readable mod, setup, add-on, server/helper source, build scripts, and pinned native dependency sources. See [SOURCE-AND-BUILD.md](SOURCE-AND-BUILD.md) to build it using your own compatible game references. `COMPONENTS.json` lists the embedded file hashes; `SHA256SUMS.txt` lists download hashes.

The files are unsigned. If antivirus reports a “crypto” warning, capture the detection name and affected file or URL/IP. Friends networking uses Tox encryption; the precise reported Malwarebytes cause remains unconfirmed. See [SECURITY.md](SECURITY.md) for network behavior and the optional friends-network setting.

## More information

[Friends and invitations](MESH-FRIENDS.md) · [Social tablet](SOCIAL-TABLET.md) · [Recovery, compatibility, and build details](ADVANCED.md)

**Testing status:** automated checks pass, but end-to-end two-player VR testing remains outstanding. This is not a standalone Quest port. Add-ons that need server-specific work before launch, such as custom-model syncing, are not integrated with the in-game picker.
